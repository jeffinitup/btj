# ## Version 3.0.0 ## #

## General
- Updated the mod to Minecraft 1.6.4. Special thanks to Arminias for the extensive low-level technical work that made this update possible.
- Integrated Ears for modern skin support (including slim models) and additional skin features. Ears by Unascribed. BTW port by Cocona20xx, with additional work by Hiracho.
- Integrated EMI for recipe viewing with a custom default theme. EMI by emi. RetroEMI by Unascribed. BTW port by TheWinABagel, with additional work by Hiracho.
- Added EMI information pages to many blocks and items, beginning an effort to provide in-game documentation. (Dawn)
- Added tooltips for blocks and items now show the name of the original mod that added them. (Hiracho)
- Added BTW specific achievements to guide player progression. (IssaMe, Sockthing, Hiracho, Dawn)
- Reworked the debug (F3) screen and added extended debug information behind the `/gamerule extendedDebugAccess`. (DraViGen)
- Added borderless fullscreen support. (Arminias)
- Added the ability to open screenshots directly from chat. (jeffyjamzhd)
- Moved non-English language support to a separate Fabric mod, accessible via a button on the in-game language page. (Hiracho)
- An additional thanks to ITL Suppress and Sanedsf, who are not otherwise listed in this changelog but who contributed to the process of 3.0 development.

## Gameplay
### General
- The "Create World" screen now includes information explaining how the default survival mode functions within BTW. (Dawn)
- Added the ability to lock a world's difficulty, enabled by default on new worlds. This can be enabled at world creation or any time in the options menu for both new and existing worlds, though note that it cannot be disabled afterwards. (Dawn)
- The Permadeath option has been removed from the default configuration, as it does not align with the mod's intended gameplay. (Note: The underlying code remains, allowing addons to easily re-enable this option.) (Dawn)
- Mob spawners now decay and become inactive after spawning a set number of mobs. Once inactive, they will still convert nearby cobblestone to mossy cobblestone but will no longer spawn creatures. This to reinforce that dedicated mob farms are the intended method of farming mob drops and xp. (Dawn)
- Increased the generation rate of exposed diamond ore in caves. This significantly boosts the amount found through caving, easing the early-game struggle for diamonds, while having minimal impact on the overall number of diamonds. (Dawn, Hiracho)
- Added Mushroom Islands to the list of blacklisted biomes for hardcore spawn. (Dawn)
- Added a configurable setting to make the first spawn in a world random using hardcore spawn rules, rather than the original world spawn location. (Hiracho)
- Added the ability to configure superflat worlds with additional structures required for progression. (Hiracho)
- Sleeping now fades the screen to complete darkness and stops rendering the world, which helps speed up the effect on lower-end computers, and discourage some of the more gamey uses of beds. (Hiracho)
- An in-game warning message is now displayed when a new world could not create a valid world spawn position. (Hiracho)

### Vanilla 1.6 Update Integration
- Reverted the vanilla 1.6 nerf to health and regeneration potions to preserve the intended value of potions. (Dawn)
- Changed the visibility improvement gained from the Respiration enchantment (added by vanilla) to cap at Respiration III. This avoids causing issues with the higher enchantment levels available in BTW. (FriedYeti)
- Added Thatch Blocks, crafted by packing 9 pieces of straw. (Dawn)
- Changed Hay Bales to be craftable only through piston packing. (Dawn)
- Changed Leads to be crafted using rope and hemp fibers. (Dawn)
- Added the ability to use Leads on Villagers. (jeffyjamzhd)
- Increased the flammability of Coal Blocks significantly compared to vanilla. (Dawn)
- Added Charcoal Blocks and Nethercoal Blocks. Nethercoal blocks burn infinitely to any side, similar to concentrated hellfire. (Dawn)
- Rebalanced the loot found in Nether Fortress chests added by vanilla to better fit the mod's progression. (Dawn, Hiracho)
- Changed how Nether Fortress chests spawn to be slightly more interesting, as well as to reduce their overall frequency. (Hiracho)
- Changed many things about horses to better fit into BTW. More information can be found in the animals section below.

### Mechanical Power
- Increased the drop rate of Hemp Seeds from grass blocks to reduce tedium and allow for a larger, more viable starting hemp farm. (Dawn)
- Added a crafting recipe for the Stone Hoe. (Hiracho)
- Iron Hoes and better now automatically convert loose dirt into hydrated farmland when used next to an already hydrated farmland block or a water source. (This effect does not extend beyond normal hydration rule ranges.) (Hiracho)
- Diamond Hoes and better no longer consume hunger when tilling soil. (Hiracho)
- Modified the primitive gear recipe to use a log, allowing the handcrank and millstone to be crafted as soon as the crafting stump is unlocked. (Hiracho)
- Halved the exhaustion caused by using a handcrank. (Hiracho)
- Restored the prior six fabric recipe for the sail, given the increased prevalence of hemp in the early game. (Hiracho)
- Changed hemp to use daily growth mechanics while growing the bottom stage, leading to more consistent growth overall. (Hiracho)
- Changed the bottom block of a mature hemp plant to always drop a hemp seed, and to no longer drop hemp. This allows for farming hemp before shears, but at lower efficiency. (Hiracho)
- Gearboxes can now be rotated with an empty hand when unpowered, even if axles are connected, simplifying placement and alignment. (Hiracho)
- Axles that are powering blocks will now break if the powered block is pushed by a piston. (Hiracho)
- The hopper filter slot now only accepts items marked as a filter and is limited to a stack size of one. (DraViGen)

### Armor
- Changed armor defense, armor weight, and associated hunger consumption to be recognized as attributes. As a result, these values are now visible in armor tooltips. (Dawn)
- Changed how knockback resistance functions to align with modern vanilla mechanics; it now reduces knockback by a set percentage instead of having a chance to negate knockback entirely. (Dawn)
- Added knockback resistance to Soulforged Steel armor. (Dawn)
- Reduced the weight of Chain Armor slightly (from 13 down to 10) to better encourage its use. A full set of Chain Armor will now no longer cause the player to sink in water. (Dawn)
- Changed the sinking threshold: armor weight now causes the player to sink in water only when the total weight is over 10, instead of starting at 10. (Dawn)
- Removed the heavy footstep sounds that played while wearing Soulforged Steel boots, as this was disruptive during gameplay. (Dawn)
- Increased the weight of the Diamond Helmet from 5 to 6 to better reflect its crafting recipe. (Dawn)
- Changed the padded armor recipe to match that of wool armor, reducing its cost and making padded armor a more appealing option. (Dawn)

### Animals
- Reduced the light level provided by Redstone Blocks. They will remain viable for early base lighting, but building animal pens with Redstone Blocks will now require a bit more investment. (Note: Please check the lighting in previously safe animal pens, as they may no longer be secure after this change.) (Dawn)
- Changed animals to only follow the player when holding a breeding item and ready to breed, instead of following any food item. Leads are now the intended way to move animals. (Dawn)
- Added Cheval as a meat drop from Horses. Cheval can be used as a substitute for steak in recipes. (Dawn)
- Changed Horses to now kick like Cows. (Dawn)
- Changed Horses to require food, aligning them with other animals. (Dawn)
- Changed Horses to be bred with cake, similar to Cows. (Note: This is a temporary placeholder and will be changed in a future release.) (Dawn)
- Updated Horse textures and models to match modern horses. (Sockthing, Inf1nlty)
- Removed the ability to tame and ride Horses. This functionality will be restored in a future release. (Dawn)
- Removed randomized horse attributes. This may return in an altered form in the future. (Dawn)
- Added the ability to craft Saddles using leather and rope. (Dawn)
- Added the ability to craft Horse Armor. (Dawn)
- Changed wool drops from Sheep to be affected by the Looting enchantment (including when using shears). (Hiracho)
- Changed block dispensers to pull more than one wool off of sheep at a time. (Hiracho)
- Changed Pigs to turn Grass Blocks into loose sparse grass when eaten, aligning their behavior with other animals while maintaining their unique grazing mechanic. (Dawn, Hiracho)
- Adjusted the hunger rate of Pigs slightly to accommodate the grass changes. This will still overall decrease the required pen size for pigs, but it will increase the items needed to keep them fed. (Dawn)
- Changed animals and mobs to actively avoid Cacti when pathfinding. (Hiracho)
- Increased the odds of wild sheep spawning with an exotic color. (Hiracho)
- Removed wild brown sheep. Brown sheep must now be acquired through breeding. (Hiracho)
- Changed Cows to no longer drop Leather, making Leather a unique drop from Horses. (Hiracho)
- Added Tundra, Tundra Hills, and regular Extreme Hills to the list of biomes where Horses spawn. (Hiracho)

### Hostile Mobs
- Pigmen can now spawn wearing gold armor. (Hiracho)
- Silverfish in the End will no longer drop clay. (Hiracho)
- Increased the drop rate of the Efficiency scroll from Silverfish (made less rare). (Hiracho)
- Significantly increased the rate at which possessed wolves spread possession to match that of a standard size (2x3) Nether Portal. (Hiracho)
- Possessed Squids no longer resist the urge to jump out of the water when actively hunting something. (Hiracho)
- Squids will now sometimes re-evaluate their current best hunting target. (Hiracho)
- Added support for variant mob spawn eggs. (Dawn)
- Added previously missing mob spawn eggs. (Hiracho, Inf1nlty)
- Reduced the minimum range at which Squids can despawn around the player in an attempt to make squid farms less dependent on the surrounding water volume. (Hiracho)
- Changed The Beast to no longer burn in sunlight, although it still prefers to remain in the shade. (Hiracho)
- Fixed a bug where The Beast only tracked the player from 16 blocks away instead of the intended 32 blocks. (Hiracho)

### Food
- Increased the chance of acquiring food poisoning from raw food to further discourage its use without proper consideration. (Dawn)
- Decreased the food value of Chowder from 2.5 to 2 shanks. (Dawn)
- Increased the food value of Tasty Sandwiches from 2.5 to 3 shanks. (Dawn)
- Increased the stack size of Cake and several unbaked foods to 16. (Hiracho)
- Changed Bread Dough to require only 2 Flour instead of 3, and water has been re-added to the recipe in the form of either a Water Bucket or a Water Bottle. (Dawn)
- Changed the Cistern to retain its water level when filling bottles. This change facilitates the revised bread recipe and makes potion brewing slightly more convenient. (Dawn)
- Changed Hearty Stew to only be craftable from Cheval, Steak, and Mystery Meat. (Hiracho)
- Changed Chicken Soup to include a pumpkin in its recipe and now returns 4 portions. (Hiracho)
- Added the ability to craft Tasty Sandwiches from Ham & Eggs and Kebab. (Hiracho)

### Storage
- Rebalanced storage options in order to provide more meaningful progression throughout the early game, while reducing dependence on wicker. See the below entries for more details.
- Changed Sugar Cane to no longer spawn in Rivers due to the decreased early game reliance on it. (Hiracho)
- Changed GUI-less storage containers like Wicker Baskets to add collected items directly to the player's inventory when space is available, instead of ejecting the items. (Dawn)
- Added Bark Boxes as a new early-game storage option with 1 slot that does not require wicker components. (Tetro48)
- Increased the number of item slots in Wicker Baskets from 1 to 4. (Tetro48)
- Changed the Hamper recipe to include Hemp Fibers. (Hiracho)
- Increased the number of item slots in Hampers from 4 to 9. (Hiracho)
- Changed the Hamper recipe to include Rope, and reduced the amount of wicker required. (Hiracho)
- Changed the recipe for Chests to include an Iron Ingot. (Hiracho)
- Changed Baskets (and the new Bark Boxes) to require an Axe of any quality to be harvested without breaking down into their component parts. (Hiracho)
- Changed Hampers to require an Iron Axe or better to be harvested without breaking down into their component parts. (Hiracho)
- Removed the recipe to uncraft Wicker Baskets. They can still be broken into components by harvesting them without an Axe. (Hiracho)
- Changed the Desert Well structure and the starting bonus chest to spawn a Bark Box instead of a Wicker Basket. (Hiracho)
- Changed dungeons in upper and middle strata, as well as temples, to spawn with hampers instead of chests. (Hiracho)
- Changed Minecarts with Chests to drop intact when broken with an Iron Axe or better. (Hiracho)

### Villages
- Removed abandoned villages and looted temples. The abandoned range originally addressed the overpowered benefit of spawning near villages or high-value temple loot, but this purpose has diminished due to the villagers spawning as zombies, farming reworks, and structure loot rebalancing. This change also makes it more feasible for players to bring villagers home, which fits better than the original plan for players to build a second base for trading. (Dawn)
- Changed crop fields to spawn with fewer crops in each, resembling a partially abandoned state. (Hiracho)
- Increased the chance of villages spawning with carrots or potatoes. (Dawn)
- Removed the anvil from the Blacksmith structure. (Hiracho)
- Changed Blacksmiths to spawn with some bricks instead of ovens. (Hiracho)
- Rebalanced the loot found in Blacksmiths, and changed the container to spawn as a Hamper instead of a Chest. (Hiracho)
- Changed the village well structure to prevent Zombies from getting stuck. (Hiracho)
- Added the ability to breed Villagers using Diamond Ingots as well as normal Diamonds, making Mystery Meat (and by extension Wolf Chops) fully renewable. (Dawn)
- Changed Zombies to always convert Villagers back into Zombies instead of having just a high chance of conversion. (Dawn)
- Changed Zombie Villagers to stay near their homes instead of wandering off. (Hiracho)
- Added the ability for Zombie Villagers to break some weaker blocks on Standard difficulty, akin to the behavior of Zombies on Hostile difficulty. (Hiracho)

### Villager Trades
- Changed Arcane Scroll trades to always be available, and the cost was slightly reduced across the board. They remain an investment but are no longer prohibitively expensive. (Dawn)
- Changed the Librarian to sell Soulforge-based technology at level 2 for emeralds plus some integral components, rather than buying it. This provides limited, earlier access to the tech while maintaining the value of the Soulforge itself. (Dawn)
- Changed the Soulforge Conversion trade to be handled by the Librarian instead of the Priest. This preserves the Wither as a requirement to fully level a Librarian. Soulforge conversion is now required to level the Librarian from Level 3 to 4, and is available at any time afterward. (Dawn)
- Changed the rare mob drop trades for the Librarian to be at Level 4, after the Soulforge trade. This slightly extends the time between killing the Wither and the Dragon, as the two boss kills felt compressed previously. (Dawn)
- Removed the Librarian trade to buy bookshelves. (Hiracho)
- Restored the ability to craft books. (Hiracho)
- Added a trade to the Librarian to turn books into Ancient Manuscripts, after the Librarian has been provided one. (Hiracho)
- Changed the recipe for bookshelves to use Ancient Manuscripts, rather than books. Together, these changes make bookshelves renewable. (Hiracho)
- Reduced the cost of purchasing equipment from the Blacksmith, and reduced the frequency of equipment trades. (Dawn)
- Changed the Blacksmith to sell Chain Armor at an earlier level, allowing the player to access it pre-Soulforge for a price. (Dawn)
- Changed the Candle trade for the Priest to only ask for primary dyes that do not require mixing, in order to reduce inventory clutter. The trade was also moved to Level 4 to better balance distribution in trades between levels. (Dawn)
- Changed the Butcher to buy cooked meat instead of raw meat, preventing situations where a player had the correct type of meat but could not trade it because they had already cooked it. (Dawn)
- Changed the Butcher and Farmer to sell food less often and in smaller quantities. (Dawn)
- Changed the Butcher to buy Saddles rather than sell them. (Dawn)
- Changed the Farmer to always sell Mycelium at Level 5. (Dawn)
- Changed various other trades in minor ways. (Dawn)

### Blocks
- Changed Leaves to be passable by entities. Jungle spiders can still stand on leaves but may pass through them when pursuing a target. (Hiracho)
- Changed Leaves to be crushed and destroyed by falling blocks. (Hiracho)
- Changed Leaves to no longer behave as if they have hard surfaces for block placements. (Hiracho)
- Changed Grass blocks to no longer loosen when dirt below is dug on Relaxed and Classic difficulties. (Dawn)
- Added the ability to harvest ovens using Silk Touch. (Hiracho)
- Added the ability to apply mortar to Brick Ovens. (jeffyjamzhd, Hiracho)
- Changed the Enchanting Table to require a diamond pickaxe to break, consistent with its obsidian base, and making early game desert temples a more interesting landmark. (Hiracho)
- Increased the range at which the vanilla enchanting table checks for bookshelves. (Hiracho)
- Added Diamond Ingot Blocks using the existing diamond block texture, and updated the vanilla Diamond Block to have a new texture. Diamond Ingot Blocks function identically to regular Diamond Blocks when used for a beacon. (Hiracho)
- Added Nether Sludge Blocks (crafted from 9 Nether Sludge), which can be used to produce hardened clay in a kiln. (Dawn)
- Renamed Wet Bricks to Wet Crude Bricks. A new Wet Brick was added as the final stage in pottery spinning on a turntable that is not washed away by water, making it easier to use in kilns. (Dawn)
- Added the ability to automatically insert and eject records from the Jukebox. (jeffyjamzhd)
- Changed the particles spawned around the enchanting table to be more colorful. (Hiracho)
- Changed Bellows to require an Iron Axe to mine, consistent with similar mechanical blocks. (Hiracho)
- Changed Jack o'Lanterns and Carved Pumpkins to interact with gravity similar to regular Pumpkin blocks. (Kitty)
- Expanded the list of blocks which prevent mob spawns to include more plant-based blocks such as lily pads and cocoa beans. (Hiracho)
- Torches can now be placed against the sides of transparent blocks, consistent with placement on top of them. (Hiracho)
- Changed newly placed Bedrolls and Beds to be flammable. Existing beds will not catch fire, to prevent existing setups from suddenly burning down. (DraViGen)
- Added the ability for Comparators to read the light level from a Detector Block & Lens light sensor. (zero318)
- Added a unique visual interaction when placing candles on a Soulforge. (jeffyjamzhd)
- Added the ability to place loose stones in the world. Up to four of the same type of stone may be placed in the same block. (jeffyjamzhd)
- Changed stumps to drop planks when sawed like normal logs, rather than dropping an intact log. (Hiracho)

### Items
- Added the ability to enchant iron chisels and shears. (Dawn)
- Added the ability to enchant shears with Looting. (Hiracho)
- Renamed vanilla shears to Iron Shears for consistency. (Hiracho)
- Added Pile of Emerald Dust, which function like soul sand piles but locate villages. (Arminias)
- Added Pile of Diamond Dust, which can be used to locate temples and witch huts. (Hiracho)
- Implemented a cooldown system for items similar to modern vanilla. (Tetro48)
- Added cooldowns to Piles of Soul Sand, Emerald Dust, Diamond Dust, and Ender Pearls. (Tetro48)
- Changed which hopper filters the gear item is able to pass through. (Hiracho)
- Added the ability to use Lily Pads as fuel, with the same fuel value as flowers. (Hiracho)

### Crafting Recipes
- Increased the difficulty of the Jukebox crafting recipe, positioning it as the most technologically advanced pre-Nether item. (Zhil)
- Changed crafting recipes with secondary outputs to insert those items directly into the player's inventory when space is available, rather than spill them onto the ground. (Dawn)
- Changed the bow de-crafting recipe to display the string as the primary output instead of the stick in order to better communicate the purpose of the recipe. (Dawn)
- Added a convenience recipe to convert a cistern into a cauldron. (Hiracho)
- Added a Cauldron recipe to bleach wool knit. (Hiracho)
- Added a recipe to craft slabs from mouldings by placing them horizontally in a crafting grid. (Hiracho)
- Added a Crucible recipe to melt Glass Bottles into Glass Panes. (Hiracho)
- Changed the Glass recipe to require one quartz and 16 sand to create 8 Glass blocks. (Hiracho)

---

## Bugs and exploits
### Exploit Fixes
- Removed the invulnerability protection upon logging into a singleplayer world. This protection remains in multiplayer where it serves a legitimate function (characters being loaded before player gains control) but was primarily used for exploits in singleplayer. (Arminias)
- Changed campfires to consume fuel and burn food significantly faster when the campfire has a large flame. This change prevents players from throwing large amounts of fuel onto the campfire and leaving it unattended; campfires must now be properly tended to cook food. (Hiracho)
- Changed how Creeper explosions are calculated to fix an exploit that allowed their explosive damage to be blocked by placing a single block directly at their feet. (Arminias)
- Changed the Sinew crafting recipe to require cooked food. This change further discourages using Sinew as a first-day option, reinforcing its intended role as a last-resort substitute for string when resources are depleted. (Dawn)
- Changed animals to enter a panic state if they are pushed excessively, this can be prevented by having them on a lead. (Arminas)
- Changed mobs to no longer drop items when they die from suffocation damage. (Dawn)
- Changed neutral mobs, such as Wolves and Zombie Pigmen, to anger nearby allies when taking suffocation damage. (Dawn)
- Changed the Chopping Block to no longer count as a solid block for the purpose of causing suffocation damage. (Dawn)
- Changed dead players to no longer load chunks around their position. (Tetro48)
- Changed the death screen to no longer render the world near the player's corpse. (Hiracho)
- Fixed an issue where the camera could clip inside walls by combining the gloom effect with a high Field of View (FOV). (Arminias)
- Fixed various Xray exploits related to being inside full blocks that do not suffocate you (Hiracho)
- Fixed an issue where placing lit Crude Torches on Leaf Block sides would crash the game (Hiracho)
- Fixed an issue where placing TNT with a Dispenser would crash the game (Arminias)
- Fixed an issue where fireballs/wither skulls would despawn above/below the world (zero318)

### Notable Bugfixes
- Fixed several vanilla issues which could cause save corruption. (Arminias)
- Fixed an issue where soul sand piles could only detect a nether fortress which had already generated. Soul sand piles should now always be able to find the nearest fortress, regardless of how far away it is. (Arminias)
- Fixed an issue where fat status effect penalties did not apply. (Arminias)
- Fixed an issue where baby wolves would not eat. (Hiracho)
- Fixed an issue where the game would stay sped up for a short time after waking up from a bed. (Arminias)
- Fixed an issue where low health and hunger affecting the ability to swim ignored changes to status effects from difficulty. (Dawn)
- Fixed an issue where status effects text would be overlapping breathing bubbles when underwater (Tetro48)
- Fixed an issue where the check for a valid fishing spot was being performed incorrectly. (Dawn, Hiracho)

### Additional Bugfixes
- Fixed an issue where arrow components could be duplicated when crafting in a stoked cauldron. (Dawn)
- Fixed an issue where beds could drop items twice upon being broken. (Arminias)
- Fixed a typo in the name of venom sac (it was previously called venom sack). (Dawn)
- Fixed an issue where blood wood benches had the wrong name. (Hiracho)
- Fixed an issue where walls added by the mod were called fences. (Dawn)
- Fixed an issue where second and third strata stone subblocks used fences instead of walls. (Dawn)
- Fixed an issue where possession would not progress while in creative mode. (Dawn)
- Fixed an issue where the player did not heal while sleeping in a normal bed. (Arminias)
- Fixed an issue where campfires only started fires on top of netherrack and not other infinitely burning blocks (like concentrated hellfire). (Dawn)
- Fixed an issue where sending a 1 tick pulse to a piston to push a tile entity deleted its data. (Hiracho, zero318)
- Fixed an issue where pistons pushing chests could form triple chests. (Hiracho, zero318)
- Fixed an issue where the player would be kicked due to an illegal stance when dying while crouching. (zero318)
- Fixed an issue where vsync did not function correctly. (Arminias)
- Fixed an issue where diamond shears had improved mining speed against blocks they were not efficient against. (PolarOnyx)
- Fixed an issue where saplings did not drop correctly from some leaves. (Hiracho)
- Fixed several rendering issues with repeaters and comparators. (zero318)
- Fixed an issue where comparators did not rotate on turntables, face the correct direction when placed by a block dispenser, or interact with buddy blocks. (zero318)
- Backported several other fixes for comparator behavior from modern vanilla. (zero318)
- Fixed issues with furnace minecarts losing power. (zero318)
- Fixed an issue where platforms were not able to lift some blocks they were supposed to be able to like redstone and minecart rails. (zero318)
- Fixed an issue with panes connecting to neighbors incorrectly. (zero318)
- Fixed an issue where white cobble slabs could not be crafted back into full blocks. (Hiracho)
- Fixed an issue where stone slabs did not interact with silk touch correctly. (Hiracho)
- Fixed an issue where ice rendered incorrectly next to non full blocks. (Hiracho)
- Fixed an issue where piston packing did not work when the chamber was built out of some blocks that looked like they should work, but didn't (like trap doors). (Hiracho)
- Fixed some issues with grass rendering. (Hiracho)
- Fixed an issue where comparators could not read from ovens, baskets, and hampers. (Hiracho)
- Fixed an issue where squids would have their possession timer reset, causing them to never fully transform. (Dawn)
- Fixed an issue where potatoes required sunlight to grow. (Dawn)
- Fixed an issue where sheep mutation colors when breeding were incorrect. (Aquila Regalis)
- Fixed an issue where the respawn button in the death screen would not be clickable after toggling fullscreen. (Arminias)
- Fixed an issue where stairs sent incorrect block updates to neighboring blocks. (Hiracho)
- Fixed an issue where mobs could spawn on barrels despite them being made of wood. (Hiracho)
- Fixed an issue where swapping items with hotkeys could bypass stack size limits. (DraViGen)
- Fixed an issue where a certain moon texture was incorrect. (Tetro48)
- Fixed an issue where maximum smooth lighting rendered incorrect dark spots on partial blocks. (Hiracho)
- Fixed an issue where spruce trees occasionally spawned without a stump. (Hiracho)
- Fixed an issue where the east and north faces of partial blocks rendered textures with the wrong offset. (Hiracho)
- Fixed an issue where some stair recipes output the wrong count. (Hiracho)
- Fixed an issue where trees could not grow through replaceable blocks. (Hiracho)
- Fixed an issue where candles were always dropping one candle when broken with an axe (Hiracho)
- Fixed an issue where slabs couldn't properly combine with an already existing slab in some cases (Arminias, jeffyjamzhd)
- Fixed an issue where bed-type block would drop items when the head of the block burned (DraViGen)
- Fixed an issue where vases and wool slabs had no color descriptor in their names (jeffyjamzhd)
- Fixed an issue where wolves were always using the friendly texture in water (DraViGen)
- Fixed an issue where the brightness of the wolf's texture would be too dark in water (DraViGen)
- Fixed an issue where a desync would occur between client/server when raining, preventing the wolf's brightness from returning to normal afterward (DraViGen)
- Fixed an issue where wolves were using friendly texture during full moon instead of hostile (DraViGen)
- Fixed an issue where wolves were incorrectly turning manhunter when a nearby wolf was targeting a player (DraViGen, Hiracho)
- Fixed Mooshroom milking rendering issue and make it panic when milked without milk (Inf1nlty)
- Fixed issues related to reloading fireball/wither skull entities (backported vanilla fixes) (zero318)
- Fixed some Falling Blocks dropping the wrong item when itemized by falling too long (Hiracho)
- Fixed an issue where particles created by Ender Spectacles and the Lapis Block beacon were glitching when the FPS was going over 200 (Hiracho)
- Fixed an issue where breaking Dung Block or Packed Earth Block with a Hoe didn't drop anything (Hiracho)
- Fixed an issue where terrain features could push a spawnpoint up to 4 chunks into blacklisted biomes (Hiracho)
- Fixed an issue where using silk touch on several slabs or double slabs returned the loose variants (Hiracho)
- Fixed an issue where the potions a Witch can drop didn't stack with player created potions (Hiracho)
- Fixed an issue where placing netherrack in the overworld did not scare away nearby animals (Hiracho)
- Fixed a rendering issue with glass panes where the east corner would incorrectly show a border in some occasions (Hiracho)

---

## Settings and Modes
### Commands
- Added the command `/panorama` for taking panorama screenshots. (Dawn)
- Backported the `/gamerule randomTickSpeed` command. (Hiracho)
- Backported the `/setworldspawn` command, allowing players to relocate the loaded spawn chunks to a better position. (Hiracho)
- Disabled the `/spawnpoint` command. (Hiracho)
- Changed the `/difficulty` command to require cheats, even in singleplayer, as it can bypass the difficulty lock. (Dawn)

### Multiplayer
- Added a configurable limit to the number of players who can share a hardcore spawn point in multiplayer. (Hiracho)
- Added a configuration option to enable local proximity text chat in multiplayer. When this setting is active, `/g` or `/global` can be used to send messages to the global chat channel. (Hiracho)

### Creative Mode
- Added a hotkey for swapping between creative and survival gamemodes, akin to that in modern vanilla: hold F3 and press F4 while cheats are enabled. (Ivangeevo)
- Added support for using Bonemeal in creative mode, consistent with how bonemeal is used in vanilla. (Inf1nlty)
- Added several missing blocks to the creative menu. (Hiracho)
- Changed the default tab in the creative menu to be the inventory tab. (EmreKumas)
- Changed creative flight to be significantly faster when sprinting, matching the behavior in modern vanilla. (Hiracho)
- Changed Brick Ovens to no longer consume fuel or items when they are being filled in creative mode. (jeffyjamzhd)
- Reworked how placing and harvesting ice blocks function internally to allow placing "Natural Ice" (obtained via cheats). Natural Ice and "non-source" Ice are now separated within the creative menu and the EMI view. (DraViGen)

### Hostile Difficulty
Hostile is a new difficulty that contains the following changes:
- Zombies and Creepers have an extended sight range. (Arminias)
- Hostile mobs search for targets within a higher vertical range. (Arminias)
- Zombies can break some weaker blocks to reach the player. (Arminias)
- Creepers will explode while close to the player, but unable to reach them, in order to breach through walls. (Arminias)
- Zombies and Creepers have increased resistance to explosion damage, facilitating the above breaching behavior. (Arminias)
- Skeletons will actively seek out Spiders to mount, instead of only happening incidentally. (Arminias)
- Skeletons have a chance to spawn as Wither Skeletons underground after the Nether has been accessed. (Arminias)
- Endermen will grab the player when they teleport. (Arminias)
- Abandoned structures are present once again. (Dawn)
- Gloom is active in the Nether as well. (Arminias)
- Portals do not emit light. (Arminias)
- Skeletons shoot flaming arrows which can set blocks and entities aflame. (Arminias)
- Skeletons have an increased shooting range. (Arminias)
- Players and other entities trample fires and campfires upon contact. (Arminias)

### Classic Difficulty
Classic is a new difficulty that is designed to more closely emulate the experience of BTW before the hardcore survival elements were added.
Note that, unlike other difficulties, classic cannot be switched to or from other difficulties due to the potential for exploits.
Classic difficulty contains all the changes of relaxed difficulty, as well as the following changes:
- Hardcore Spawn is disabled. (Dawn)
- Permanent Torches can be crafted from coal. Nethercoal still serves to increase recipe efficiency. (Dawn)
- Cows and Horses do not kick. (Dawn)
- Hunger-intensive actions drain even less hunger. (Dawn)
- Health regenerates even more quickly. (Dawn)
- Only the first stage of health and hunger penalties apply (only removing sprint), and they take effect later than usual. (Dawn)
- Clay Bricks cannot be trampled. (Dawn)
- Ovens can be picked up intact. (Dawn)
- Mining blocks without the correct tool is even faster. (Dawn)
- Chisels drop full ore items instead of piles. (Dawn)
- Stone tools are faster to use. (Dawn)
- Stone tools do not require string to craft. (Dawn)
- Stone Pickaxes break stone in a single hit. (Dawn)
- Tall grass has a chance of dropping wheat seeds, similar to vanilla. (Dawn)
- Weeds do not grow at all. (Dawn)
- Farmland does not require re-tilling after crops are harvested. (Dawn)
- The top block of Hemp may be harvested without destroying the whole plant even without Shears, though Shears are still much faster. (Dawn)
- Progressive crafting items (such as wicker weaving) progress faster. (Dawn)

---

## Resources
### Textures
Note: Some mod textures use licensed assets from other sources are provided under MIT and MPL v1.1 licenses; please see the included license file for detailed source information.
Licensed assets will be replaced with custom assets in future versions.
- Updated all in-game textures to match modern vanilla textures. (Dawn, Zeyke, Sockthing, Franzy)
- Updated block models to reflect the new art direction. (jeffyjamzhd)
- Added an official programmer art resource pack for players who prefer the old textures. (Dawn)
- Added the ability to use legacy FC models through resource pack metadata. (jeffyjamzhd)
- Renamed all mod textures. (Dawn)
- Removed many unnecessary duplicate textures. (Dawn)
- Added a new title screen logo. (Sockthing)
- Changed Work Stumps to have unique top textures per type. (Dawn)
- Changed Mystery Meat and Wolf Chops to have unique textures. (Dawn)
- Changed Stoked Fire to use a dedicated texture file instead of being dynamically generated. (Hiracho, Ikabod)
- Added a config file for MCPatcher settings. (Hiracho)
- Added CTM (Connected Textures Mod) textures for Glass and Glass Panes. (Hiracho)

### Sounds
- Revamped many of the mod's sounds using audio assets from modern vanilla. (Notable changes are listed individually below.) (Dawn)
- Added Squid sounds. (Dawn)
- Added placement sounds for Doors, Cocoa Beans, and Signs. (jeffyjamzhd)
- Added sound effects for Paintings, Canvases, and Item Frames. (jeffyjamzhd)
- Changed Witch sounds. (Dawn)
- Changed sounds for things you shouldn't worry about. (Dawn)
- Changed many block and item sounds. (Dawn)
- Changed sounds when Endermen teleport out of a dimension. (Tetro48, Hiracho)

---

## Addon API
### Architecture
- Flattened BTW subclass overrides into class edits. This means that Better Than Wolves (BTW) versions of vanilla blocks, items, and entities have been removed in most cases, with behavioral changes now implemented directly through class edits. (Dawn)
- Split API and mod content into separate packages. (Dawn)
- Changed addons to be loaded through the standard Fabric loader instead of a custom loader. Addon information (name, version, etc.) is now loaded from Fabric configuration files instead of the addon constructor. (Cocona20xx)
- Removed mod prefixes, favoring the use of the Fabric mod ID instead. (Dawn)
- Changed addon lookup methods to use the mod ID instead of the display name. (Dawn)
- Changed assets and language files to be loaded from the addon namespace. Language files no longer require an addon-specific prefix and are simply named the same as the base language file, but located in the addon's namespace. (Dawn)

### World Data
- Overhauled world data handling. World data is now managed by registering Data Entries through $api.world.data.DataProvider$ instead of creating a $WorldData$ subclass. (Dawn)
- Added the ability to store data for the player in the same way as storing data for the world. (Dawn)
- Added the ability to sync player and world data to the client. (Note: This data is not synced instantaneously and is therefore unsuitable for real-time client information.) (Dawn)

### Difficulty
- Overhauled difficulties to be constructed through $api.world.difficulty.DifficultyProvider$ instead of creating a $Difficulty$ subclass. (Dawn)
- Added the ability to define new difficulty-controlled parameters without requiring mixins. (Dawn)
- Removed the ability to query the world against a specific difficulty. Difficulties can now only be accessed by requesting the value of a particular parameter, in order to reduce the potential for addon conflicts. (Dawn) 

### Attributes
- Added hooks to specify whether an item should apply attributes when held and when worn. (Dawn)
- Added hooks to allow attribute modifiers on items to display as descriptor strings instead of always showing raw values. (Dawn)
- Added a helper class for managing attribute arithmetic operation types. (Dawn)

### Entities
- Added hooks for entity components, allowing extension of entity behaviors. (Dawn)
- Added entity variant components, and changed skeletons and wither skeletons to use them internally. (Dawn)
- Added hooks to determine block-specific Enderman behavior (e.g., which blocks can be picked up) directly within the block class, instead of being hardcoded in the Enderman class. (Dawn)
- Added hooks for blocks to determine if they can be destroyed by the Wither. (Hiracho)
- Added possession sources so an entity knows what possessed it. This is currently used for achievements but is available for other purposes. (Dawn)

### World Generation
- Added a ForkableRandom class, which allows duplicating an existing random object without affecting the original object. This is primarily useful for making modifications to world generation without disturbing vanilla generation. (Zhil, Arminias)
- Added the ability for biomes to define block metadata as well as block IDs as their surface blocks, and added support for block IDs above 256. (Dawn)
- Added hooks to generate loot in any type of container within structures. (Hiracho)
- Added hooks to add loot to structure loot tables. (Hiracho)
- Added hooks to define the rotation of blocks when generated in a structure. (Hiracho)

### Blocks and Items
- Removed deprecated hooks for replacing block, item, and entity classes, as these have been superseded by mixins. (Dawn)
- Added hooks to determine if a block is usable as a hopper filter. (DraViGen)
- Added a new UV coordinate override system as part of RenderBlocks. (jeffyjamzhd)
- Changed block item rendering to allow for defined block color to take effect. (jeffyjamzhd)
- Added many generic categorization tags. (Dawn)
- Changed hopper and bellows filtering to be controlled by tags. (Dawn)
- Moved beacon effect handling into its own class, separate from the beacon tile entity itself. (Dawn)
- Improved Item ID conflict logging. (TheWinABagel)

### Additional APIs
- Added hooks for adding addon info to the F3 debug menu. (DraViGen)
- Moved color functionality to its own package, consolidating previously scattered code. (Dawn)
- Rewrote how villager trades are defined to clean up the related code. (Dawn)
- Implemented support for forcing a spawnpoint. Addons can use this directly or re-enable `/spawnpoint` to allow a fixed spawn location. (Hiracho)


# ## Version 2.1.4 ## #
- Changed the respawn button text to change according to whether the respawn is a fresh hardcore spawn or a repeat of the same spawn. (Dawn, Arminias)
- Fixed an issue where options.txt files from modern versions could crash the game on load when using the vanilla launcher. (Arminias)
- Fixed an issue in multiplayer where stacking companion slabs would crash the server. (Arminias)
- Fixed an issue in multiplayer where the client would disconnect from the server when dying. (Arminias)

# ## Version 2.1.3 ## #
- Changed the respawn button in the death screen to read "Respawn Randomly" to reflect the mechanics of hardcore spawn.
- Changed the chat messages which appear on death.
- Changed the in game hp display to always show hardcore-styled hearts (this may be disabled in the config).
- Changed the name of survival mode to "Hardcore Survival", and the name of vanilla's hardcore (when enabled through the config) to "Permadeath".
- Changed ghasts to inflate slightly before attacking. (Arminias)
- Changed the damage tilt to respect the direction the damage was taken from. (Arminias)
- Added beaches to the list of banned biomes for hardcore spawn, to prevent the player from spawning on a jungle beach.
- Fixed an issue where hardcore spawn was not properly avoiding banned biomes (jungles and oceans) when respawning the player. (Hiracho)
- Fixed an issue in multiplayer where clients could crash when placing a nethercoal torch. (Arminias)

# ## Version 2.1.2 ## #
## General
- Added an accessibility option to the config to change the intensity of (or completely disable) the nausea effect from all sources. (Hiracho)
- Removed the millstone-specific accessibility option as it is replaced by the more general version above. Note that you will need to set the config again to disable nausea if you previously had this option set. (Hiracho)
- Updated the Turkish translation. (efe the physis)
- Updated the Chinese translation. (Pot_tx)
- Updated the German translation. (Sockthing)
- Changed the colors in the names of various items to be localized. (Pot_tx)

## Gameplay
- Changed sinew to require two meat instead of one, only be able to be made with beef or wolf chops, and require working afterwards as well. Sinew was never intended to be a cheap alternative to string, and was instead meant only as a solution to running completely out of string. The initial design missed that mark significantly, se these changes are intended to bring it more in line with the original intention.
- Changed hardcore spawn to not respawn the player in rivers to prevent cases where players were still able to respawn in jungles by spawning in rivers inside of one. (Hiracho)
- Changed soul urns to no longer be directly used on nether plants to fertilize it, and instead will attempt to fertilize nearby blocks when thrown. This was done primarily to fix an issue where you could end up doing both if you had multiple souls urns in your hand and end up wasting them. (Hiracho)
- Changed soul urns to be more dangerous when thrown without a valid target. (Hiracho)
- Removed the ability to select vanilla's hardcore mode when creating a new world or server. Hardcore mode directly conflicts with a lot of BTW's design, is not an intended method of play, and leads to lots of players unintentionally having a worse experience. A config option exists to re-enable it, for those who know exactly what they are doing and the ramifications that  enabling hardcore mode has.
- Fixed an issue where villagers could attempt to populate their trade list with a trade they already had, leading to them missing a trade from their list.
- Fixed an issue where ovens that spawned in villages were non-functional. (Hiracho)
- Fixed an issue where dying in a different dimension to your bound soulforged steel beacon would not respawn you at the beacon. (Hiracho)
- Fixed an issue where the message for items being destroyed on subsequent deaths did not respect the number of deaths require to destroy items, determined by the current difficulty.
- Fixed an issue where the game could crash when generating villages. (Arminias)
- Fixed an issue where the player's position was calculated incorrectly while in a bed. (Arminias)
- Fixed an issue where the client would crash when attempting to connect to a multiplayer server without first opening a singleplayer world. (Arminias)
- Fixed several issues in multiplayer caused by desync due to time being sped up while in a bed. (Arminias)

# ## Version 2.1.1 ## #
- Fixed an issue where a null pointer error with pistons could cause chunks to not save correctly.
- Fixed an issue where block breaking by hand was slower in relaxed mode instead of faster due to an order of operations issue.

# ## Version 2.1.0 ## #
## General
- Changed status effects names such as peckish to be localized instead of hardcoded.

## Gameplay
### General
- Overhauled difficulty selection as a way to better provide alternate methods of play, without compromising the curated experience BTW offers. Difficulty levels are now stored per-world and can be decided at world creation, in addition to the options menu.
    - Standard mode: The default mode of play, and the one players have become familiar with over the years.
    - Relaxed mode: A slightly less punishing experience, while still maintaining the same depth and meaningful gameplay as standard mode. Overall gameplay length for optimal play is comparable to standard mode, but it should be easier for players to get their feet under them.
- Changed the difficulty command to affect the new system of difficulty modes. It can be used to change the current mode by typing in the mode's name, or to view the current mode by using the command without arguments. This may be used at any time in singleplayer, without requiring cheats, or by operators in multiplayer.
- Removed the ability to change the difficulty from the main menu given that difficulty is now saved per-world.
- Added the ability for sugar cane to spawn in rivers. Given that finding sugar cane no longer lets you expand a farm infinitely, and given how vital it is for early game storage, I felt it appropriate to make it somewhat more common. Swamps and jungles are still the most effective places to find sugar cane, however.
- Added the Tangled Web as a new item which drops if a spider's web fails to find a valid location to place itself as a block. The tangled web may be crafted with a sharp stone and then worked into a single string, or it may be cut directly into two string in a crafting grid with shears.
- Added the ability to make bedrolls from hemp fibers.
- Added Sinew as an alternative to string for crafting tools (stone tools, ladders, bows, bedrolls, etc). Sinew can be obtained by crafting meat with a sharp stone or chisel. This is intended as a way to help assist in cases where string availability is low by allowing the player to sacrifice some food to create more string.
- Added the ability to make potash from straw.
- Added the ability to mill zombie and creeper heads into rotten flesh and nitre, respectively.
- Added the ability to display multiple status effects (e.g. peckish and hurt) at the same time on the HUD, instead of only the highest priority.
- Changed the most severe hunger penalty from "dying" to "starving", and the second most severe from "starving" to "emaciated", to distinguish from the health status effect also called "dying".
- Changed mobs to once again drop burned meat when they die while on fire in standard mode.
- Changed fire aspect to be available again through the vanilla enchanting table.
- Changed wheat crops to harvest the entire plant when breaking the top block, and changed the selection box to include the entire plant. Wheat was never able to grow its top back, so allowing breaking only the top block only served to confuse players.
- Changed the recipe for obtaining seeds from wheat manually to also output straw to match the hopper recipe for doing so automatically.
- Changed (increased) the radius which a lightning rod protects.
- Changed how lightning is attracted to blocks (and entities). Previously, areas protected by blocks other than lightning rods were not actually fully protected, but with this change standard pillars of blocks should be enough to protect a small area, while lightning rods can be used to cover a much larger area.
- Changed how mob spawning checks for leaves internally to improve behavior with non-vanilla leaves.
- Changed ocelots to only spawn on leaves, and to require light to spawn, to stop them from spawning inside chicken pens, and allow preventing their spawns within jungle spider farms.
- Changed mobs to not spawn on wool, including beds and bedrolls.
- Fixed an issue where mobs were able to spawn on wicker.
- Fixed an issue where wolves would become permanently angry at the player when attacked by another mob. (Hiracho)
- Fixed an issue where saplings only dropped as an item when fully mature. (Hiracho)
- Fixed an issue where looting did not apply consistently to head drops from mobs. (Hiracho)
- Fixed an issue where sprinting using ctrl did not consume as much hunger as it should. (Arminias)
- Fixed an issue where a player who died while on fire while also bound to a steel beacon would drop burned meat instead of rotten flesh.
- Fixed an issue where blood wood trees checked against the biome instead of the dimension when checking for whether they were in the nether, causing issues with alternate nether biomes from addons.
- Fixed an issue where using pick block on a burning campfire gave a burning campfire as an item.
- Fixed an issue where several crafting recipes did not work for strata stone variants.
- Fixed an issue where cobblestone walls always dropped first strata stones.
- Fixed an issue where sparse grass and mycelium returned fully grown versions when silk touched.
- Fixed an issue where mushroom cap blocks were named incorrectly.
- Fixed an issue where mandatory trades for villagers did not always properly refresh.
- Fixed an issue where the mandatory status of a trade was not properly written to or read from NBT.
- Fixed an issue where mandatory trades displayed a "+" in the gui, despite not giving xp. Note that this fix may not apply until the trade is completed and refreshed due to the above NBT issue.
- Fixed an issue in multiplayer where attempting to dye armor would crash the client. (Arminias)
- Added additional logic to handle syncing players in multiplayer, which should hopefully fix the invisible players issue. (yany)

### Relaxed Mode
Relaxed mode is designed to increase accessibility, and provide a slightly less challenging experience while still maintaining the depth and richness of standard mode, largely by reducing punishments for failure in order to make recovery easier. Focus is generally on decreasing some of the pressure caused by health, hunger, and time management, as well as some of the more punishing failure states, without affecting complexity or depth of mechanics.
Relaxed mode contains the following changes:
- Health regeneration is increased.
- Hunger costs associated with some particularly taxing actions are decreased. Actions affected are: Jumping, sprinting, swimming, using a hand crank, and starting a fire.
- Modifiers from health and hunger are less punishing.
- Hardcore spawn maximum radius does not increase.
- Reduced radii for looted temples and abandoned villages, both to decrease the distance required to travel in order to find them, and to make it more likely to find interesting structures when respawning after a death.
- Lightning strikes do not start fires.
- Nethercoal torches do not start fires. Note that this is accomplished through a separate block id, so any torches placed in relaxed mode will never start fires, even if a world is changed to standard mode. Torches placed in standard mode will automatically convert to relaxed mode torches over time, and will not start fires while in relaxed mode.
- Pigmen do not become angry when hit by ghast fireballs.
- Jungle spiders do not attack unless provoked, and deal food poisoning for a shorter duration on hit.
- Squids do not attack players who are not in water, or who are in boats, even at night.
- Cows deal reduced damage and knockback when kicking.
- Cows do not panic if the player attempts to milk them when they aren't ready.
- Mobs drop cooked meat instead of burned meat when dying while on fire.
- Blocks are mined slightly faster when mining without the correct tool.
- Blocks can be placed while in the air.
- Animals do not startle when placing or breaking blocks.
- Animals and wolves will not die when starving, although you still need to keep them fed to get anything from them. Starving tamed wolves will also not turn hostile.
- Weeds will not kill plants, although weeds will still cause plants to stop growing when present.
- Items dropped on death are never destroyed, even on subsequent deaths.

## Addon API
- Added a new method to WorldData to initialize default global data when a world is created.
- Added hooks for addons to add their own difficulty levels. Difficulty levels are also designed to be mixin friendly in order to modify existing difficulty levels (e.g. by adding new behavior controlled by difficulty, or editing values for behaviors in existing difficulties).
- Changed how status effects from health, hunger, etc are handled internally to make them extensible to addon authors.
- Changed how crashes occur due to an invalid mob being spawned to make the generated crash report more useful in debugging.

# ## Version 2.0.4 ## #
## Gameplay
- Added the ability to chop melons into mashed melon with an axe in a crafting grid.
- Fixed an issue causing problems with animals being able to pathfind to eat by reverting the previous change to make animals stop eating while fleeing.
- Fixed an issue where fishing could work in much smaller than intended bodies of water in some circumstances.
- Fixed an issue where saplings would not grow into a tree after maturing.
- Fixed an issue where the daily growth flag was not being updated properly on saplings.

## Addon API
- Fixed an issue where PillarBlock was marked as client only.
- Fixed (hopefully) an issue where getBiomeGenForCoords was not available on server. This should fix a crash caused by BTA in multiplayer.

# ## Version 2.0.3 ## #
- Fixed an issue where the recipe for white candles was incorrect.
- Fixed an issue where the recipe for converting old saplings to new ones was incorrect.
- Fixed an issue where spruce and birch leaves dropped each others' saplings.
- Fixed an issue where piston shoveling a block which does not drop an item would cause the game to crash.

# ## Version 2.0.2 ## #
## General
- Added support for Chinese character input. (Peakstep)
- Updated the German translation. (Sockthing)
- Updated the Turkish translation. (slzei)

## Gameplay
- Added a config option to determine whether the changes to snow should be enabled, disabled by default. The snow changes need quite a bit more work to be properly ready, so for now I am disabling them by default, but leaving the option for those who want to keep it. Note that data is preserved between options, so it is completely safe to change the status of this config without any effect on worlds.
- Added new saplings which follow daily growth mechanics. Old saplings may be converted in a crafting grid.
- Added bubble particles which spawn around a fish hook when it is in a valid fishing location. (PlasmaFox)
- Added the ability to retrieve candles from a stack by right clicking with an empty hand.
- Added the ability to create hearty stew from chicken.
- Changed the trade to buy more sugar cane roots from the farmer to be guaranteed, gave farmers an extra trade slot from level 2 onwards to accommodate, and significantly reduced the trade cost. However, as a guaranteed trade, it will no longer grant experience.
- Changed how determining whether a body of water is large enough for fishing works to use a diamond instead of a square. The same size body of water is still required, but it should be slightly more forgiving if there are stray blocks near the corners of the checked area.
- Changed (increased) the amount of hunger restored by cured meat from 1 shank to 1.5.
- Changed saplings to be crushed by falling blocks.
- Changed undead mobs to no longer attempt to light on fire while it is raining to prevent the constant extinguish sounds. (PlasmaFox)
- Removed the nearby monster check for sleeping in a bed. In vanilla this was meant as a simulacrum of making sure your bed is safe, but since BTW simulates the world while you sleep, the mobs will just come and kill you :). (Cocona20xx)
- Fixed an issue where the screw pump melted down into too much iron. (PlasmaFox)
- Fixed an issue where the recipe for converting old carrots into new carrots did not work.
- Fixed an issue where white candles could not be crafted.
- Fixed an issue where animals would continue their eating animation while fleeing. (PlasmaFox)
- Fixed an issue where candles were missing an ignite sound when lighting them. (PlasmaFox)

## Addon API
- Added a new TreeGrower class to help addons create new saplings, as well as to reduce code duplication between tree growth from saplings and world gen.
- Added hooks to add tree growers to existing saplings (and remove them).
- Added hooks for any sapling to have a 2x2 variant.

# ## Version 2.0.1 ## #
## General
- Added several new splash texts.
- Added translation entries for beacon respawn messages.

## Gameplay
- Changed arrows to produce 2 per craft instead of 4 (broadhead arrows unchanged).
- Changed potatoes to use daily growth.
- Changed (reduced) the drop rate of extra potatoes, and removed poisonous potato drops.
- Fixed an issue where fully grown wheat generated incorrectly in villages, forcing to player to wait for the rest of it to grow.
- Fixed an issue where non oak log types would strip off too many layers when chiseling.
- Fixed an issue where an in progress work stump would always display the oak stump texture on top.
- Fixed an issue where work stumps always turned into oak chewed logs.
- Fixed an issue where the server would accelerate time as if all players were asleep when nobody was online.
- Fixed an issue where packed earth slabs would turn into loose dirt slabs when losing their anchor block.
- Fixed an issue where ladders would render incorrectly in certain directions.
- Fixed an issue where some effects didn't play sound.
- Fixed an issue where registering a command in singleplayer would crash the game.
- Fixed an issue where firework rockets without a firework star would still crash the game.
- Fixed an issue where crops which did not require sunlight required slightly higher light level than intended.

# ## Version 2.0.0 ## #
Thanks to the following people who contributed to this release!
- Dawnraider
- Arminias
- Zhil
- Hiracho
- Sockthing

## General
- Refactored the entire mod in order to make development significantly smoother. Unfortunately, this means all addons will break with this release and will need to be updated. Details of the refactor are expanded upon below.
- Changed BTW to officially use fabric. Fabric loader is now required to install BTW.
- Fixed an issue where the addon finder would not properly locate addons located in the mods folder on linux.
- Fixed an issue where the game wasn't able to properly run on MacOS on Apple Silicon. Note that the experience is still not perfect and will likely need to wait for an update to MC 1.6 to be fully fixed but it is now significantly more playable.
- Fixed an issue where the game would crash on Java versions higher than 8. Now anything 16 and below will work (Java 17 is still not compatible).

## Gameplay
### General
- Added the ability for wheat to grow under light blocks.
- Changed nether portals to work in any size from 2x3 all the way up to 21x21 (the same as modern vanilla).
- Changed lily pads to be placeable again, but removed the ability to place other blocks against lily pads. This allows decorative use of lily pads without allowing for the exploits which originally led to them being disabled.
- Changed enchanting tables to be able to detect bookshelves an additional block up or down, for a total of 1 block below the enchanting table to 2 blocks above.
- Fixed an issue where there really was nothing to worry about regarding releasing souls into the environment without being captured.
- Fixed an issue where stone and cobblestone could drop the wrong metadata under certain circumstances.
- Fixed an issue where the config for large biomes HCS was not functioning.
- Fixed an issue where ovens and baskets would render with entirely black insides in certain circumstances (for real this time!).
- Fixed an issue where launching a firework rocket would crash the game.
- Fixed an issue where kiln blocks did not count as being mortared for the purpose of sticking loose blocks to them.
- Fixed an issue where the carrot on a stick was still using the old carrot for crafting.
- Fixed an issue where the time would reset on HCS on a server if two people were connected, instead of the intended one person.

### Beds
- Fixed an issue where the player would be treated as being up to 3 blocks tall while in a bedroll, leading to mobs seeing the player over walls.
- Fixed an issue where the player would always face north in a bedroll.
- Fixed an issue where they player could wake up on the other side of a wall from a bed if that wall left open a block next to the corner of the bed.
- Fixed an issue where raytracing to find cursor placement did not function properly while in a bed.

### Beacons
- Added spider eye blocks and slabs, made by packing 16 spider eyes.
- Added the ability to construct a beacon from spider eye blocks to prevent jungle spiders from spawning in the area.
- Changed (increased) the drop rate of spider eyes.
- Fixed an issue where mobs spawned from beacons ignored the updated mob spawning rules in BTW based on material instead of block shape.

### Pistons
- Added the ability to push tile entities with pistons.
- Fixed an issue where lava pillows would leave lava behind when moved by a piston.

### Snow
- Changed (reduced) the amount which snow height affects movement speed when walking through it.
- Fixed an issue where snow on slabs would render with invisible sides, although it does still render darker than intended.

### Logs
- Added separate top textures per log type.
- Added separate chewed log variants per log type.
- Changed work stump conversion to be slightly faster, and to occur in two shorter steps rather than one single long step, in order to help with clarity as it could be difficult to tell if the player was doing the correct thing or not.

### Wolves
- Changed wolves to no longer require food or produce dung while possessed.
- Changed wolves to reset their aggression when fed mystery meat.
- Fixed an issue where wolves would not always update their texture to properly reflect their aggression status.
- Fixed an issue where wolves aggro'd in a group would very quickly lose their aggression state if they could not reach the player.

### Aesthetics
- Added the ability to stick things to the flat face of trapdoors.
- Added the ability to climb trapdoors which are above a ladder and attached to the same face.
- Changed trapdoor placement on flat surfaces to be more intuitive.
- Changed iron spikes and lightning rods to have a slightly larger base when multiple candles are resting on them.
- Changed fence gates to no longer require a block below when placing.
- Changed fences, walls, and panes to connect to any solid surface, not just solid blocks, and improved wall rendering.
- Changed panes to connect to walls.
- Changed mod stone fences to walls.
- Fixed an issue where mod fences rendered differently in inventory from vanilla fences.

## Creative Mode
- Changed torches to no longer go out in inventory when in creative mode.
- Fixed an issue where pick block did not work on candles.
- Fixed an issue where blood wood bark did not appear in the creative menu.

## Addon API
- Fixed an issue where addons still needed to be referenced from a base class. They will now be loaded and initialized automatically.
- Added packet handlers as a more elegant way to handle custom packets. The previous override methods in BTWAddon (formerly FCAddOn) have been deprecated and will be removed in a future release.
- Added custom entity and custom item entity handlers as a part of the above rework, which have hooks to allow addons to use them as well for custom entities.
- Added an effect handler to manage custom effects. The previous override method for clientAuxFX in BTWAddon has been deprecated and will be removed in a future release.
- Added a hook to blacklist placing blocks against another block.
- Added hooks for mining charges and explosions to define behavior after the block is set to air.
- Added hooks to define whether a block can connect to fences, walls, or panes towards a specific facing.
- Added a hook to detect when an entity steps through a block.
- Changed command registration to be done through BTWAddon instead of ServerCommandManager, which also fixes an issue where commands were being registered too late on servers.
- Changed beacon effects to be defined dynamically instead of being hardcoded to allow for addition of new effects.
- Added hooks to define new local ambient beacon effects (similar to how looting beacons function).
- Deprecated hooks for block, item, and entity replacement, as fabric mixins replace this behavior in a much more elegant and powerful way. These hooks will be removed in a future release.

## Refactor
- Updated project compliance to Java 8.
- Moved all BTW classes into their own packages separate from Minecraft's.
- Renamed all classes. The FC prefix has been removed (as individual packages make the clarification redundant), and most classes have had their name hierarchy reversed (e.g. from FCBlockStoneRough to RoughStoneBlock).
- Renamed all methods to no longer use a capital letter. In almost all cases this is the only change to methods.
- Renamed all fields to remove hungarian notation. Also changed constants to use CONSTANT_CASE.
- Moved block and item definitions to their own classes, separate from the main BTW class.

# ## Version 1.4.1 ## #
Thanks to the following people who contributed to this release!
- Dawnraider
- Sockthing

## Gameplay
- Fixed an issue where the game would crash when fishing
- Fixed an issue where beds did not properly speed up time
- Fixed an issue where the corpse eye was missing its texture

# ## Version 1.4.0 ## #
Thanks to the following people who contributed to this release!
- Hiracho
- Dawnraider
- Quanteus
- Sockthing

## General
- Changed several hardcoded message strings to be exposed to translation files:
	- Steel beacon binding messages
	- Death messages
	- Cannot sleep in bed message
	- Too exhausted to hand crank message
	- Wind mill and water wheel placement error messages
	- Ancient manuscript use message
- Updated some entries of the German translation.
- Updated some entries of the Russian translation.
- Fixed an issue sometimes causing the insides of hampers, ovens, and other blocks to render completely black.

## Gameplay
### General
- Added the ability to stick swords into companion cubes.
- Added strata variants for stone products (cobblestone, stone bricks, etc).
- Fixed an issue where piston packing was ignoring metadata in recipes.
- Fixed an issue where glowstone could not support falling blocks.
- Fixed an issue where flowering carrots did not render weeds.
- Fixed an issue where healing still hadn't actually been made faster.

### Beds
- Re-enabled beds. Yes really. Beds now simulate the world instead of skipping time. Thanks to Arminias for originally writing the code for this through his bed addon!
- Added bedrolls as a new type of bed, crafted shapelessly with two wool knit and a string. Note that you will not regenerate health while sleeping in a bedroll.
- Changed beds to no longer drop themselves when broken, instead dropping some of the components used in crafting it. However, health will regenerate while sleeping in a bed.
- Changed beds to no longer explode in the nether or end, and instead simply prevent you from sleeping.
- Changed beds to no longer set your spawn point. Steel beacons are still the only way to do this.

### Candles
- Added a new candle item and block which functions the same as vanilla's candles. Up to 4 candles may be placed in a single block, with the light level emitted increasing with the number of candles present.
- Changed candles to be made with only a single piece of tallow, producing 4. This keeps the cost per light level the same as before, since candles now individually put off much less light unless combined.
- Changed old candles to drop 4 new candles for consistency.
- Removed the light output from redstone torches, repeaters, and comparators as rapid lighting updates in redstone circuits can severely impact performance. Note that redstone blocks will still output light for an early game option, and candles now provide new aesthetic low light options.

### Death
- Added the Corpse Eye, crafted with a soul urn, an ender pearl, and a piece of mystery meat, which functions similarly to an eye of ender, but instead points to the location of the player's last death.
- Changed items dropped on death to last indefinitely, as long as you do not die again. If you die a second time, not counting soft respawns which put you at the same HCS, your items from your previous death will be lost.
- Changed zombie villagers to drop mystery meat on death.

### Snow
- Added the ability for snow layers to be stacked.
- Added the ability for snow to collect over time during a storm, increasing in depth to follow the terrain.
- Changed snow to slow you by an amount based on the depth of the snow.

## Addon API
- Added a hook to define item textures based on state (like the bow drawing animation).
- Added a hook to allow special-casing sticking tools into blocks they otherwise would not be able to be placed in.

# ## Version 1.3.10b ## #
## General
- Changed server version checking to ignore lettered versions. This means that future versions with the same number and only differing in the ending letter will be treated as server compatible. Do note that this does not apply to 1.3.10. While 1.3.10 clients can connect to a 1.3.10b server without issue, they will still receive a warning when joining.
- Fixed a crash in multiplayer on startup due to the log file being improperly initialized.

# ## Version 1.3.10 ## #
## General
- Fixed an issue where the game would load addons installed directly into the jar out of order (note that specifying load order for mods loaded from the mods folder is yet supported)
- Fixed an issue where a null pointer error would be logged if no addons were installed in the ./mods folder.
- Fixed an issue where the addon loader was percent encoding file URIs leading to it looking for files in the wrong location.

# ## Version 1.3.9 ## #
Thanks to the following people who contributed to this release!
- Dawnraider
- Zhil
- Hiracho
- slzei

## General
- Added the ability to load addons from the ./mods folder. Note, however, that addons must declare their main addon class in their own package as the loader will not check the base MC package.
- Added several new splash texts, and removed a few that no longer fit with the current state of the mod. Thanks to everyone who suggested new splash texts!
- Tweaked some translation entries for the Turkish translation.

## Gameplay
- Added a config option to disable the HCS radius increase in large biomes.
- Changed hardcore spawn to try not to respawn the player in the jungle or ocean. Do note that it is still possible to spawn there if no other location is found within a reasonable time.
- Changed the block dispenser to only place a minecart in the world if one is not already present in front of it.
- Changed block dispensers to eject minecarts with some velocity if a rail is present.
- Changed the position at which a block dispenser places a minecart without rails to make it easier to fit them down a 1x1 hole.
- Changed minecarts with chests to be more predictable when spilling items when broken.
- Changed hoppers to no longer reset the number of contained souls when the soul sand filter is removed to make it more difficult to circumvent breaking the hopper when not powered.
- Changed tools to no longer be placed inside of replaceable blocks to prevent using them to put out fires.
- Changed snow placed during world generation to fill in tall grass and other snowloggable blocks.
- Changed (increased) the volume of the splash sound when a fish grabs a fish hook.
- Fixed an issue where crafting crucibles on a turntable did not eject a clay ball.
- Fixed an issue where carrots required natural light to grow.
- Fixed an issue where the health regen changes from last release did not get applied to multiplayer.
- Fixed an issue where some block place events were using the step sound instead of the place sound.

## Addon API
- Added hooks to define behavior when entities are consumed by a block dispenser.
- Added hooks to prevent the player from respawning in certain biomes.
- Added hooks to change the volume and pitch of different block sounds (place, step, break) independently of one another.
- Added hooks to define more properties for daily growth crops.

# ## Version 1.3.8 ## #
Thanks to the following people who contributed to this release!
-Dawnraider
-Sockthing
-slzei

## General
- Added a German translation. Thanks to Sockthing for providing the translation!
- Added a Turkish translation. Thanks to slzei for providing the translation!
- Fixed an issue where grass blocks rendered the grass overlay on top of dirt instead of on top of the base grass texture.

## Gameplay
- Changed the player to go up ladders more slowly when using an item.
- Changed the player's health to regenerate slightly faster to reduce the time wasted. This should make little difference in combat, but should reduce downtime by a small amount
- Changed (reduced) the amount of food chickens get from eating items like seeds.
- Removed the ability for pigs to eat sugar cane in the world, since they are unable to eat sugar cane items anyway, and since pigs eating sugar cane roots has a much bigger negative impact than before sugar cane was reworked.
- Fixed an issue where blocks with different sounds based on metadata (like sand slabs) would not play their custom sounds on place or break.
- Fixed an issue where the screw gave back too much iron when melted down in a crucible.

## Addon API
- Added a hook for addons to disable HC bouncing without editing EntityPlayer.
- Fixed an issue where rain particles would spawn during snow in biomes with only partial snow coverage.

# ## Version 1.3.7 ## #
Thanks to the following people who contributed to this release!
- Dawnraider
- Peakstep

## General
- Added a Simplified Chinese translation. Thanks to Peakstep for providing the translation!

## Gameplay
- Changed the recipe for the screw. The recipe remains the same shape, using a column of three iron ingots in the center, while the outer ingots have been changed to nuggets. This should help make screw pump towers a little more accessible in the mid game, without completely devaluing their cost.
- Changed vanilla armor types to have equal durability across armor slots to match mod armors.

## Addon API
- Changed the type passed in to the world decorator hook from last release from BiomeDecorator to a new interface FCIBiomeDecorator, which BiomeDecorator implements.
- Changed the hook for checking for valid snow placement to pass the current world as an argument.
- Fixed an issue where some instances of the game checking for snow did not use the new hook.

# ## Version 1.3.6 ## #
## Gameplay
- Fixed an issue where sawing corners of wood types with metadata would create gears with metadata which wouldn't stack together or work in recipes. Additionally, recipes involving gears have been changed to ignore metadata so that existing bugged gears can be used.
- Fixed an issue where diamond shears made no sound when used in crafting.

## Creative Mode
- Changed health/hunger status effects to not apply when the player is in creative mode.

## Addon API
- Added hooks to FCAddOn to allow addons to define behavior for decorating the world (for things like trees, ores, etc)
- Added hooks to allow biomes to define whether it can snow at a certain location.
- Changed the checks for breaking the saw to check for if a block has a recipe, removing the need to also disable breaking the saw in the block's class.

Thanks to the following people who contributed to this release!
- Dawnraider
- yany

# ## Version 1.3.5 ## #
## Gameplay
- Fixed an issue where moonlight was erroneously block mobs from spawning on slabs and other partial blocks.
- Fixed an issue where scattered features (temples and witch huts) were not generating properly.

# ## Version 1.3.4 ## #
## Gameplay
- Added the ability to block with the refined hoe since its right click functionality has been freed up.
- Fixed an issue where smelting nether bricks in an oven still used nether sludge instead of unfired nether brick.
- Fixed an issue where using fireworks would cause the game to crash.
- Fixed an issue where saws in multiplayer were checking against material incorrectly.
- Removed the recipe for the old unfired brick block in the kiln, since it is no longer obtainable, in order to help craftguide keep clutter down.

## Creative Mode
- Fixed an issue where unfired nether bricks returned the wrong result when using pick block.
- Fixed an issue where stone always returned its first strata variant when used with pick block.

# ## Version 1.3.3 ## #
## Gameplay
- Fixed an issue where chopping logs with an axe produced 4 planks instead of 2.
- Fixed an issue where several BTW materials would erroneously break the saw. I made sure all vanilla materials were updated to the new system but missed the BTW materials.

## Creative Mode
- Fixed an issue where wet bricks returned the wrong result when using pick block.

## Addon API
- Fixed an issue where saw and kiln recipes weren't properly checking for if they should ignore metadata.

# ## Version 1.3.2 ## #
Thanks to the following people who contributed to this release!
- Dawnraider
- Hiracho

## Gameplay
- Added the ability to put a breeding harness on mooshrooms without them being converted into normal cows.
- Changed fire aspect to no longer be available on the vanilla enchanter given that it is now significantly stronger than before, especially when exploring. It may now only be obtained through the infernal enchanter.
- Changed mobs to no longer be able to spawn on wicker as a thematic extension of not being able to spawn on wood, and because hampers and baskets being spawnable was unintuitive.
- Changed campfires to startle animals when placed to fix an exploit with setting animals on fire in the early game.
- Fixed an issue where clay balls were still used to make bricks in an oven instead of wet bricks.
- Fixed an issue where the tops of blocks would not have biome coloring applied when smooth lighting was turned off.
- Fixed an issue where mooshrooms did not have textures for hungry or starving states, and changed them to only grow mushrooms on their backs when fully fed.
- Fixed an issue where slimes in swamps did not respect the new lighting requirements for spawning.
- Fixed an issue (again) where clients would disconnect from multiplayer when sneaking/pressing alt use/sprinting. Version control issues meant the code for this change did not actually make it into last release.

## Creative Mode
- Fixed an issue where several blocks returned the block instead of item form when using pick block: iron and gold ore chunks, various pastries, unfired pottery.
- Fixed an issue where unfired pottery was not present in the creative menu.

## Addon API
- Added hooks to define whether a material breaks the saw or not.
- Added the ability to define multiple valid input metadata values for a single saw or kiln recipe, instead of requiring a separate recipe for each metadata, and updated BTW recipes to use this system. This is primarily to help craftguide to display recipes properly.
- Added static arrays to FCRecipes holding the metadata values for siding, moulding, and corners, to assist in defining in-world recipes such as those on the saw.
- Added a warning when attempting to add a hopper filtering recipe with an input stack size greater than 1.
- Added hooks to set a block to define whether a block should startle animals when placed or removed.
- Added hooks to define log chopping recipes, and separated existing recipes into their own instances. The old FCRecipesLogChopping class has also been deprecated, and will be removed at a later date.
- Changed turntable recipes to be handled by a crafting manager.
- Fixed an issue where helper methods for adding subblock recipes to the saw were not public.

# ## Version 1.3.1 ## #
Thanks to the following people who contributed to this release!
- Hiracho

## General
- Fixed an issue where mod initialization in multiplayer would still cause crashes on launching the server.

## Gameplay
- Added the ability to sprint by pressing alt use (defaulted to ctrl) while moving.
- Added the ability to place several orientable blocks with the opposite rotation by holding alt use while placing.
- Changed sprinting to not cancel when hitting blocks as long as movement input is still activated.
- Fixed an issue where pressing alt use while moving in multiplayer would disconnect the client.

# ## Version 1.3.0 ## #
Thanks to the following people who contributed to this release!
- Dawnraider
- Hiracho
- ExpHP
- rockoutwill
- Quanteus

## General
- Added a full Russian translation. Thanks to Quanteus for providing the translation!
- Fixed an issue where texturepacks took a very long time to load.
- Fixed an issue where a couple of translation entries were duplicated.

## Gameplay
- Added new grass and mycelium growth mechanics, which are detailed further below.
- Added a new system for farming silverfish in the end, based loosely on the old system, which is left to the player to discover.
- Added the ability to turn a stack of bark into potash.
- Added a new keybinding as an alternate use key, bound to ctrl by default, allowing items to have multiple right click functionalities.
- Added the ability to place swords into soft materials using alt use + right click.
- Changed tools to be placed using alt use + right click to allow adding right click functionality to tools and to decrease the occurrance of accidentally placing tools. This also enables placing of steel tools.
- Changed buckets to be placed using alt use + right click, allowing them to be placed once again without requiring block dispensers.
- Changed hostile mobs to only spawn in complete darkness (aka gloom) in order to decrease torch spam. Note that they can still spawn in sunlight of 7 or less so normal nighttime spawns are unaffected when artifical light is not present.
- Changed cactus to be able to be planted on itself for decorative uses. Note that the base plant must still be placed in a planter.
- Changed dragon orbs to collide with blocks in the same way as items, which should hopefully make them easier to work with in automated systems.
- Changed the recipe for mining charges to produce 3 instead of 2.
- Changed the ender spectacles overlay to remove the green tint.
- Fixed an issue where crafting dynamite with soul dust still only produced 1.
- Fixed an issue where cooking recipes still used the old carrot.
- Fixed an issue where sugar cane roots could be placed on top of other sugar cane plants.
- Fixed an issue where combining slabs played the block's step sound instead of its place sound.
- Fixed an issue where upside down slabs which started falling (such as when a dirt slab lost its anchor) immediately rendered as normal slabs instead of rendering as upside down.
- Fixed a vanilla issue where the game would be unable to load a save if you exited with a fishing line cast.
- Fixed an issue in multiplayer where the game would crash when generating mountains.
- Fixed an issue in multiplayer where the game would crash when a player died with items in their inventory.

## Animageddon
- Added sparse grass as a new grass growth stage. When eating grass, animals will turn grass into sparse grass instead of dirt, and animals will only eat sparse grass when they are starving. This makes animal pens far less subject to snowballing failure and makes it easier to tell if a pen is too small before it is too late. Note that pigs are an exception to this and will still turn grass directly into loose dirt.
- Added sparse mycelium which serves the same purpose as above. Furthermore, this fixes an issue where mooshrooms would create patches of spawnable ground on the surface of mushroom biomes.
- Changed grass to be able to grow under artifical light so long as it can still see the sky, meaning grass can now grow at night as long as it is lit. This fixes an issue where animals could die through no fault of your own simply by leaving your base for several days in a row, returning only at night.
- Changed (reduced) the distance which grass and mycelium can grow downwards from 3 blocks to 2. This fixes an exploit where animal pens could be constructed with grass roofs to significantly improve their output. The primary purpose of these, preventing snowballing, has now been handled as a legitimate feature through sparse grass and mycelium.
- Changed grass slabs to use their own block ids instead of sharing with dirt slabs. Old grass slabs in the world will convert to the new ones over time, and a conversion recipe has been provided to convert the old items into the new ones.
- Changed (removed) the light level requirement for mycelium to grow as it ran somewhat counter to its purpose in blocking mob spawns, and didn't make a lot of sense when mushrooms would still grow without light. This also increases the value of mooshrooms by allowing pens for them to be built without sunlight.
- Changed (refactored) how grass and mycelium spread are handled internally.
- Changed (refactored) how grass rendering is handled internally.
- Changed (increased) the food value multiplier for pigs slightly to account for the changes made to grass spread, since they did not benefit as much from the new mechanics.
- Changed (reduced) the overall necessary pen size for animals as the old values were far too cumbersome to make use of late game.
- Changed (increased) the food value items provide to animals significantly, as feeding animals with items was entirely unreasonable to do previously.
- Changed animals to once again drop cooked meat if they die while on fire. With mobs setting you on fire and animals dropping burned meat, fire aspect was a wholly detrimental enchantment and this should hopefully return some value to it.
- Fixed an issue where animals could not eat ferns.
- Fixed an issue where mycelium slabs could not be combined with dirt slabs.
- Fixed an issue where combining two grass slabs resulted in a dirt block.

## Creative Mode
- Fixed an issue where the new silverfish blocks were missing translation entries.

## Addon API
- Reformatted FCAddOn class to make it more clear what kind of functionality is present for addon authors.
- Added hooks to get block light value only, ignoring sunlight.
- Fixed an issue where several FCAddOnHandler methods were not static.
- Fixed an issue where naturally spawned entities were not respecting class mapping replacements.
- Fixed an issue where block and item replacement used the wrong method overloads when registering addons for mutual replacement.
- Removed deprecated versions of block and item replacement as a part of the above fix.
- Removed deprecated versions of secondary output recipe definitions.

# ## Version 1.2.3 ## #
Thanks to the following people who contributed to this release!
- Dawnraider
- Hiracho

## Gameplay
- Added the ability for mob spawners to convert loose cobblestone into mossy cobblestone.
- Added silverfish versions of mossy, cracked, and chiseled stone brick, and changed strongholds to generate those variants.
- Changed silverfish variants to use their own block ids to open up metadata for later.
- Changed windmills to be completely destroyed by lightning instead of dropping as an item to encourage protecting windmills from storms.
- Changed (increased) the weight on the soul urn trade for the priest to make levelling the priest from 4 to 5 less frustrating.
- Changed the canvas trade for the priest from level 5 to level 4 to further improve levelling a priest from 4 to 5.
- Changed the dynamite recipe to output 2.
- Changed mining charges to drop items as if the blocks were mined instead of their normal explosion drops.
- Fixed an issue where the butcher still requested old carrots.
- Fixed an issue where invalid trades were not being properly removed from villager trade lists.
- Fixed an issue where guaranteed villager trades, like runed and infused skulls, displayed the "+" for xp even though such trades do not provide xp.
- Fixed an issue where smooth lighting did not properly apply to grass and grass slabs.
- Fixed an issue where grass slabs erroneously always used better grass for their sides when that was enabled, even when it should have used the default texture.
- Fixed an issue where the mysterious gland, witch wart, and vessel of the dragon were missing from the creative inventory.
- Fixed an issue where magenta and light blue were swapped when mixing colors for sheep.

## Addon API
- Added hooks to define custom behavior when a block is destroyed by a mining charge.
- Added hooks to define whether a block can be converted by a mob spawner.
- Added hooks to define new silverfish invested variants.

# ## Version 1.2.2 ## #
## Gameplay
- Added the ability to make scrambled eggs out of fried and poached eggs as well as raw ones for convenience.
- Changed (increased) the drop rate of jungle saplings to match that of the other sapling types.
- Changed (reduced) the time required for trees to grow slightly to make farming trees more viable, while still requiring a significant time to grow.
- Changed the sound on sheep regrowing their wool to be more appropriate.
- Fixed an issue where attempting to reel a fish in would sometimes immediately re-apply bait to the rod instead of reeling it back in.
- Fixed an issue where applying bait to a fishing rod with a right click would consume bait from every valid stack instead of only the first.
- Fixed an issue where the drops from legacy sugar cane depended on the order the blocks were broken in.
- Fixed an issue where sugar cane and pumpkins were not properly generating.
- Fixed an issue in multiplayer where the game tried to load world data before mods were initialized.

## Addon API
- Added hooks for blocks to define their light value dynamically instead of being fixed per blockID.

# ## Version 1.2.1 ## #
Thanks to the following people who contributed to this release!
- Dawnraider
- yany

## Gameplay
- Added mashed melon as a new item produced when melons explode, and reduced the number of items produced. Mashed melon may be manually crafted into seeds, or passed through a wicker filter in a hopper. This allows melons to be accessed as a food source before having access to the saw, while still maintaining the saw as a far more efficient way of eating melons.
- Added sounds and particle effects to saplings growing into trees in a fertilized planter.
- Added the ability to right click a fishing rod to apply bait from the hotbar from yany's Click Bait addon.
- Changed full moons to be slightly less effective for catching fish given the increase in efficiency by incorporating click bait.
- Changed hardcore spawn to reset the time to day on a server with only one player online.
- Refactored how sheep color blending is handled to clean up the related code and fix some inconsistencies.
- Fixed an issue where a sapling which failed to grow from a fertilized planter would turn the planter into a sapling.
- Fixed an issue where saplings would not consume fertilizer when they matured.
- Fixed an issue where baby sheep had far too much fur.
- Fixed an issue where chicken feed could not be made from carrot seeds.
- Fixed an issue where chickens affected by Nothing to Worry About did not have their feather drops increased when their normal drops were changed.

# ## Version 1.2.0 ## #
Thanks to the following people who contributed to this release!
- Dawnraider
- Hiracho
- Sockthing

## General
- Updated the title splashes.
- Fixed an issue where config options were not being properly saved.
- Fixed an issue where better grass did not work for mycelium.
- Fixed an issue where better grass did not work for grass slabs.

## Gameplay
- Added several new systems to update more crops to vegehenna. These changes are detailed individually further below. Note that this will be expanded upon in future releases to eventually update all crops to vegehenna standards.
- Added the ability to silk touch clay ore, and removed the ability to convert old vanilla clay into unfired clay (as that was done by using clay ore's item id). It has been long enough since the original clay change that I find it very unlikely people still have clay that has not been converted.
- Added the ability to use fortune on clay ore to increase the amount of clay dropped.
- Added the diamond armor plate, and renamed the steel one to differentiate it. It may be crafted with 2 leather straps with a diamond ingot in the middle, and padding below the diamond ingot. The steel armor plate recipe has also been tweaked to match for consistency.
- Changed diamond armor to require diamond armor plates in a similar manner to steel armor (straps replacing the shoulders and legs, and added on the chin, for 7 total), though the recipes still use the 3x3 anvil. This should hopefully allow iron armor a bit of room to breathe by making diamond armor a tad more expensive and slightly lossy when melted down.
- Changed sheep to display their original wool color when shorn.
- Changed wicker baskets to return all the wicker used in crafting them instead of only 1 to make the transition to hampers less frustrating given the sugar cane changes below.
- Changed hamper's selection and hit boxes to better match their model.
- Changed sails to be crafted with 3 fabric instead of 6 to reduce the amount of time spent early game waiting for hemp to grow. This should also make hardcore spawns across oceans slightly less punishing.
- Changed (reduced) the maximum hardcore spawn range after entering the end to scale linearly with the other range increases instead of being dramatically higher.
- Changed (reduced) the lockout timer on being assigned a new spawn location after dying. Now if you die after night falls you should be assigned a new location instead of simply death looping until morning. This should hopefully reduce some of the frustration of dying again immediately after a hardcore spawn.
- Changed (increased) the minimum food value for the player on rapid respawns within the same day so that the player should no longer respawn unable to jump.
- Removed the scaling minimum distance for hardcore spawn. The minimum is now fixed with only the maximum scaling in order to increase the chances of landing on old bases to generally make HCS reward overworld infrastructure more.
- Removed the water bucket from the bread dough recipe as it made bread a pain to craft.
- Fixed an issue where wolves would eat loose food on the ground even when not hungry.

## Vegehenna
- Added sugar cane roots, which are now required to grow sugar cane as the sugar cane item may no longer be planted (though it may still be placed on top of plants with roots). New roots can be bought from the farmer or found by exploring, as newly generated sugar cane plants will generate with roots which can be picked up and moved. The growth rate of sugar cane has been increased to offset new plants being much more rare. Old sugarcane plants will continue to function as normal so as to not break builds. Old plants will also drop roots when their base block is broken to make conversion easier.
- Added a new carrot item, which is used for the new carrot crops. Old carrots will function as they used to so as to not break old builds. A crafting recipe has been provided to convert old carrots to new carrots.
- Added a new flowering carrot plant, which can be obtained by planting a whole carrot. Flowering carrots drop carrot seeds when harvested.
- Added a new carrot plant grown from carrot seeds, which drops a single carrot when harvested. Both kinds of carrot plants use daily growth like wheat.
- Changed the textures for carrots and wheat crops.
- Changed (increased) the chance of villages to have carrots or potatoes slightly to make explorating for them a little less frustrating.
- Changed (increased) the base growth level of crops in villages to reduce the amount of waiting necessary to be able to harvest the crops.
- Changed saplings to drop their current growth stage when broken instead of reverting to base.
- Changed saplings to grow faster when fertilized.
- Changed saplings to not grow into trees when placed in unfertilized planters. Be careful though, as fertilized saplings may find planters too restrictive for their growing root system.
- Removed the ability to craft melons into slices by hand, making the saw now the only way to do so. This makes melons less effective as a source of food while travelling by decreasing their efficiency in inventory. Note that seeds may still be obtained without a saw by dropping the melon from a sufficiently high location.
- Fixed an issue where pumpkins or melons exploding could cause seeds to get stuck in neighboring blocks.

## Creative Mode
- Fixed an issue where farmland returned loose dirt when using pick block.

## Addon API
- Added hooks to define custom tile entity renderers without a base class edit.
- Added hooks to define valid biomes for biome-specific generators: pumpkins, sugar cane, villages
- Added hooks to determine whether a particular addon is installed.
- Added hooks to allow for mutual replacement of blocks and items between addons by allowing one addon to define its replacement as able to override the replacement of another addon.
- Fixed an issue where addons with no config options defined would display an error to the console.

# ## Version 1.1.8 ## #
## Gameplay
- Changed (increased) the chance of breeding villagers producing a villager of a different profession than the parents.
- Fixed an issue where TNT exploding could still cause a crash in some instances.
- Fixed an issue where chopping logs with a stone axe always produced oak bark.

## Addon API
- Added the ability for addons to add custom villagers to existing castes in order to allow addon villagers to be bred from vanilla ones.
- Added the ability for addons to define their own castes for villager breeding.
- Fixed an issue where defining villager professions with non-consecutive ids would cause the game to crash when a villager of that profession was created.

# ## Version 1.1.7 ## #
Thanks to the following people who contributed to this release!
- Dawnraider
- Zhil

## General
- Fixed an issue where falling sand would generate an error on chunk generation.
- Fixed an issue where comparators had the wrong recipe.
- Fixed an issue where the game would crash when a platform began moving.
- Fixed an issue where the game could crash when a max level villager tried to refresh its trades.

# ## Version 1.1.6 ## #
## Gameplay
-Fixed an issue where the saw and kiln could output items with 0 stack size.

# ## Version 1.1.5 ## #
## Gameplay
- Fixed an issue where diamond shears could not be used to cut leather.
- Fixed an issue where hemp could not be harvested using shears.
- Fixed an issue where placing a brick in multiplayer would crash the server.
- Fixed an issue where the game would crash upon entering the end.
- Fixed an issue where throwing an egg would crash the game.
- Fixed an issue where throwing a snowball would crash the game.
- Fixed an issue where lighting a powder keg would crash the game.
- Fixed an issue where casting a fishing rod would crash the game.

# ## Version 1.1.4 ## #
Sorry to keep spamming releases, the new entity spawning code touched a lot of places and I was bound to miss a few while testing.

## Gameplay
- Fixed an issue where the game would crash when throwing a splash potion.

# ## Version 1.1.3 ## #
## Gameplay
- Fixed an issue where diamond chisels were unable to split stone into stone bricks.
- Fixed an issue where the game would crash when trying to spawn a lightning bolt.

# ## Version 1.1.2 ## #
## General
- Fixed an issue where clients would crash in multiplayer when more than one person joined the server.

# ## Version 1.1.1 ## #
Thanks to the following people who contributed to this release!
- Dawnraider
- rockoutwill

## Gameplay
- Fixed an issue where the game would crash when attempting to spill items out from a mod inventory which was broken.

## Addon API
- Changed how reflective constructor calls are handled to be less strict about primitives which can normally be passed as arguments.
- Fixed an issue where the game would crash on load when trying to reflectively use a block or item constructor that was not the first constructor defined for that type.

# ## Version 1.1.0 ## #
This release will cause issues with craftguide. It will definitely no longer be able to display kiln and saw recipes, but may cause bigger issues than that. I am unfamiliar with the craftguide codebase but I am definitely willing to work with anyone who is to get it functional again. Once it is fixed though, it should have increased functionality due to how a lot of the BTW-specific recipes are now handled.

Also, apologies to addon authors for breaking things so soon again, this will also break any addons which use custom recipe classes or which add recipes for the saw, kiln, piston packing, or secondary output recipes.

Thanks to the following people who contributed to this release!
- Dawnraider
- Zhil
- Hiracho
- rockoutwill

## General
- Refactored the code for the skin fix to be less janky.
- Removed the config option for skin URLs since it is no longer necessary with the integration of Zhil's skin fix.

## Gameplay
- Added diamond shears, crafted in the same manner as iron shears. Diamond shears do not take durability damage when used in crafting. This and the chisel below use the same id as deco's item, so they will be counted as the same item for those using deco (once deco is updated for CE).
- Added diamond chisels, crafted with a single diamond ingot. Diamond chisels do not take durability damage when used in crafting.
- Added the ability to filter wheat through a wicker filter in a hopper to separate out seeds and straw, allowing for automated farming of wheat once again.
- Added the ability to create chicken feed in a cauldron.
- Added the ability to apply mortar using a vanilla dispenser facing a block which can accept mortar.
- Added a config option to disable nausea from grinding netherrack in the millstone.
- Added a config option to enable hardcore soulmating after the nether has been accessed. If this is enabled, players will always spawn together after dying, regardless of progression.
- Added the ability to craft the comparator, using the same recipe as the repeater but with a redstone eye in place of the clock, and a third redstone torch above the middle.
- Added the ability for the comparator to read the contents of the hopper. This replaces the previous functionality where the hopper would output power when full, which has been removed. This also fixes an issue where a full hopper would permanently lock a dispenser placed below it.
- Changed the redstone eye to be crafted using only a single row of lapis, and moved it to be craftable on a normal crafting table.
- Changed regular and detector rails to be crafted with 6 iron nuggets instead of ingots. Regular rails now produce 12 instead of 16, while detector rails still produce 6.
- Changed powered rails to be crafted with 6 iron nuggets for the rails, a stick in the center, and a redstone latch in the bottom center, still producing 6.
- Changed wolves to be bred using mystery meat, and removed all restrictions on wolves entering breeding mode, including allowing wild wolves to breed.
- Changed wolves to get extra excited after killing a player.
- Changed the player to drop less mystery meat from being fat, but increased the minimum slightly (from 1-11 to 2-4).
- Changed the player to drop rotten flesh when bound to a soulforged steel beacon. The previous behavior was encouraging the player to construct suicide booths in order to obtain large quantities of mystery meat. Sacrificing villagers (preferably with a looting weapon or beacon) is the intended way to do so.
- Changed (increased) the amount of mystery meat dropped by villagers from 1-2 to 1-3.
- Changed (increased) the amount of leather dropped by cows from 0-2 to 1-3 to make investing the effort to kill a cow feel a little more rewarding.
- Changed (increased) the number of feathers dropped by chickens from 0-2 to 1-3. This, along with the arrow change, should hopefully make feathers feel like less of a restrictive resource.
- Changed arrows to once again craft 4. Arrows felt far too costly to the point of feeling prohibitive, and it was discouraging players from using bows even into late game.
- Changed the recipe for steel broadheads to produce 2 arrowheads instead of 6 to maintain a similar steel cost for broadhead arrows.
- Changed the number of items traded for the priest's skull trade and several raw meat trades for the butcher to make them consistent with other similar trades.
- Changed (reduced) the price of saddles from the butcher.
- Changed (rebalanced) a few of the outlier librarian trades to be less obnoxious.
- Changed (reduced) the spawn rate of ghasts in the nether. It is still considerably higher than vanilla, but the old spawn rate would spam ghasts and make tunneling the only viable strategy, which was not particularly enjoyable. The nether will still continue to be quite dangerous, but surface travel will at least be possible now. A config option has been provided for those who wish to maintain the old spawn rate.
- Changed blaze powder to be crafted by grinding blaze rods in a millstone. Blaze powder may no longer be crafted by hand.
- Changed vanilla stair recipes to produce 6 instead of 4 to match the stair recipes in BTW.
- Changed rough stone which has been chiseled beyond the first stage to explode into items when picked up by a block dispenser to fix a stone duplication exploit.
- Fixed an issue where burning villagers still dropped cooked meat instead of burned.
- Fixed an issue where sugar cane could be placed inside water.
- Fixed an issue where endermen would forget their aggro status on reloading the world.

## Creative Mode
- Added water and lava source blocks to the creative menu.
- Added powered axles to the creative menu. This allows testing mechanical devices without having to worry about constructing something to generate mechanical power.
- Fixed an issue where jungle spiders were missing spawn eggs.
- Fixed an issue where villager spawn eggs were missing translation entries.

## Addon API
- Rewrote how entity creation is handled. Entities now must go through EntityList.createEntityOfType() in order to be created, which allows for much smoother entity class replacement for addons.
- Added hooks to save global data to level.dat.
- Added the ability to define piston packing recipes which combine multiple items into a single block.
- Changed recipes for hopper filtering, piston packing, the saw, and the kiln to use crafting managers, allowing recipes to be added or modified without overrides.
- Changed secondary recipe outputs to store their secondary outputs in the crafting manager when assigned instead of relying on hardcoded info.
- Changed the kiln cooking overlay to be automatically rendered for blocks which have a kiln recipe so that it no longer needs to be hardcoded in RenderBlockSecondPass()
- Changed the config file handler to regenerate the config file (with the selected options) every time the game is loaded in order to preserve the options order defined by the addon instead of appending any new options to the end of the file
- Changed (refactored) block and item replacement to be a bit more robust. There should not be any addon-facing changes, however.

# ## Version 1.0.1 ## #
Thanks to the following people who contributed to this release!
- Dawnraider
- Hiracho

## General
- Fixed an issue where MCPatcher's Better Grass did not function, and added a config option to enable it (it is disabled by default).

## Gameplay
- Fixed an issue where endermen aggro was calculated incorrectly and could aggro from behind 2 high walls even without line of sight.
- Fixed an issue where mining a piston in the same tick as it extended would cause the game to crash.

## Addon API
- Added hooks to define how many babies should spawn when breeding.
- Fixed an issue where the FCBlockDirectional template was absent.

# ## Version 1.0.0 ## #
This version WILL break any addons using the Extended Addon API, which has been deprecated, with functionality now being integrated into BTW itself. Most changes that are addon-facing are relavtively minor though so updating should be easy. Addons not using the API should be unaffected.

Note that it is not safe to downgrade worlds opened in this release to a previous BTW release as this version changes how villagers are stored in the save file. Old saves can be ported without issue, but they cannot be reverted.

If you are currently using the API, this version will require a clean install.

Thanks to the following people who contributed to this release!
- Dawnraider
- Zhil
- yany
- IssaMe
- Hiracho

## General
- Integrated Extended Addon API into BTW. This is detailed further below. Addons using the API will need to update to be compatible.
- Integrated MCPatcher into BTW.
- Added a version display on the main menu.
- Completely rewrote how config files are handled. It is now automatically generated under config/BTW, and the old config file has been deprecated.
- Removed the config option for minecart changes as it really didn't serve much purpose.
- Fixed an issue where the tops of grass slabs did not respond properly to custom biome colors using MCPatcher.
- Fixed an issue where skins would not show up due to an API change from Mojang. This replaces the need for Zhil's skin fix.

## Gameplay
- Added the ability to piston pack ender pearls.
- Re-enabled the redstone comparator. It is only available in creative mode for now but will be added to survival at a later date.
- Re-enabled the speed potion effect, although the potions may still not be crafted. This is primarily for addons or custom maps to make use of the effect.
- Added the ability for the comparator to read the contents of the following blocks: block dispenser, cauldron, crucible, millstone, pulley, and vessel of the dragon. Hoppers have their own detection method right now which will be changed in the future once comparators are available in survival.
- Added the ability to uncraft windmills back into sails.
- Changed dirt, grass, and mycelium slabs to turn into loose slabs when their anchor block is lost instead of exploding into items.
- Changed flowers to be crushed by falling blocks to fix an exploit where they could be used to mine dirt in the early game.
- Fixed an issue where baby animals would prioritize following adults over eating and could starve to death if they could not reach any nearby adult they were trying to path to.
- Fixed an issue where baby animals would try to path up jumps too tall for them and get stuck jumping continuously. This doesn't catch all possible edge cases but will catch the majority the player is likely to encounter through normal gameplay. Specifically, if the block has a top surface you can stick things to, babies will not try to path up it. If the block does not have such a top surface but is still more than half a block tall (such as the back side of stairs), the baby will still attempt to path up it. However, this is unlikely to occur unless the player purposefully creates such a scenario.
- Fixed an issue where wolves were unable to be bred. They may now be bred using kibble, but must be hand fed and at full health and hunger (this is what the behavior was before the bug was introduced). This behavior, however, is a placeholder and will be changed in a future release.
- Fixed (theoretically) a bug where players would become invisible to each other when they left each other's loaded chunks in multiplayer. The fix for this was rather hacky, so let me know if anyone still has this bug occur for them.
- Fixed an issue where villager trade weighting was not being applied evenly and was incorrectly biased towards some trades.
- Fixed a vanilla issue where slimes could spawn inside of blocks when splitting, resulting in suffocation or them escaping through walls.

## Creative Mode
- Added creative mode as an officially supported gamemode. Bug reports and feedback about creative mode are now welcome.
- Added villager spawn eggs for each profession as a result of the below villager change in the API section.
- Changed the creative menu tabs for tuning forks, metal fragments, and bone fish hooks to be more appropriate.
- Removed limitations imposed on creative mode for the following mechanics: possessed cows birthing mutants, wolves converting to beasts, villages spawning zombies, villagers gaining xp, beacon effects, arcane scroll drops, and ender pearls (this was actually vanilla but has been changed for consistency with modern versions of vanilla).
- Fixed an issue where several blocks or items were not present in the creative inventory: vessel of the dragon, detector block, chainmail armor, mail item, crude torch, unlit torch, bloody chopping block, blight, soul sand planter, and farmland (since it can no longer be created in creative mode given the hoe changes). Subblocks will be added eventually but require more work than just adding them to the menu.
- Fixed an issue where the technical block glowing detector logic displayed in the creative inventory.
- Fixed an issue where several blocks gave the wrong result when using pick block: white stone, blight, stone bricks, and wooden sub-blocks.
- Fixed an issue where gamerule doFireTick did not properly disable fire.
- Fixed an issue where equipment defined by custom mob spawners was not being applied to mobs spawned from the spawner.

## Addon API
Most changes are equivalent to Extended Addon API 1.1.4. Those which are not are either new features, or the differences are specified further in the changelog:
- Added a directional template block like logs which can support up to 4 subtypes.
- Added the ability for addons to add villager professions by splitting professions into their own classes and removing a lot of the hardcoded methods related to trades.
- Added hooks to add and modify villager trades.
- Added hooks to play special effects on level up or when certain trades are performed.
- Added hooks for automatic version checking.
- Added hooks to be able to replace references to existing blocks and items.
- Added hooks to define custom item entities.
- Added hooks to replace custom entities.
- Added hooks for addons to intercept existing client packets to change their behavior.
- Added hooks to define a block's map color per metadata, and optimized map rendering to be more memory-efficient.
- Added hooks to allow an addon to save data as a part of the world file. This data is saved uniquely per dimension.
- Added hooks to allow addons to generate and process config files.
- Added hooks to define custom criteria for mobs spawning during world gen.
- Fixed an issue where trying to remove a cauldron or crucible recipe with fewer outputs than inputs would cause the game to crash on load.
- Fixed a vanilla issue where trying to spawn an entity with an ID above 255 in multiplayer would crash all nearby clients.

Changes from API 1.1.4:
- Changed the name of AddonBlockDirectional to FCBlockDirectional.
- Chnaged how the hooks for defining villager trades work to no longer be hardcoded to the class. All trades are handled through method calls which add them to the appropriate list. Invalid trades are also handled automatically now so hooks for determining if a trade is invalid have been removed.
- Changed version checking to be done in their own methods instead of the generic handler methods. This should not matter for addons unless they implement custom version checking.
- Removed AddonExt. All addon functionality has been moved into FCAddon. No change should be necessary except changing the superclass of addons back to FCAddOn for any which were using the API.
- Removed the server acknowledgement check from addons as it was not functioning properly in some cases (and could spam clients with chat messages). This will be re-introduced at a later date in a better form.
- Fixed an issue where breeding villagers always produced farmers.
- Fixed an issue where villager trade lists were still using 4.B0000002 trades and not the updated versions.
- Fixed an issue where butchers put on their breeding harness a level too early.
- Fixed an issue where replacing entity mappings did not work for spawnable mobs.
